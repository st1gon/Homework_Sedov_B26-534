# Python Practice - Variant 3

Решение практических задач по основам Python (Вариант 3).

## Структура проекта

- `task1_chess_matrix.py` — Задача 1: Матрица с шахматным узором
- `task2_longest_series.py` — Задача 2: Самая длинная серия
- `task3_char_frequency.py` — Задача 3: Частотный словарь символов
- `task4_rotate_matrix.py` — Задача 4: Разворот матрицы
- `task5_anomaly_detection.py` — Задача 5: Поиск аномалий
- `task6_sales_analysis.py` — Задача 6: Анализ продаж
- `task7_similar_strings.py` — Задача 7: Поиск наиболее похожих строк
- `task8_retry_decorator.py` — Задача 8: Декоратор повторного запуска
- `task9_store_catalog.py` — Задача 9: Товары интернет-магазина
- `task10_task_manager.py` — Задача 10: Планировщик задач
- `main.py` — Точка входа для демонстрации решения всех задач

## Запуск

Запустить демонстрацию всех решений:

```bash
python main.py
```

Каждая задача также может быть запущена отдельно:

```bash
python task1_chess_matrix.py
```
