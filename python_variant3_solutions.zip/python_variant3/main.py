from task1_chess_matrix import create_chess_matrix
from task2_longest_series import longest_series
from task3_char_frequency import top_three_chars
from task4_rotate_matrix import rotate_matrix_clockwise
from task5_anomaly_detection import find_anomalies_pure
from task6_sales_analysis import generate_sales_file, analyze_sales
from task7_similar_strings import find_most_similar_strings
from task8_retry_decorator import retry
from task9_store_catalog import Store, Book, Electronic
from task10_task_manager import TaskManager, Task

def main():
    print("=== Выполнение всех задач Варианта 3 ===\n")

    print("--- Задача 1 ---")
    print(create_chess_matrix(3, 3))

    print("\n--- Задача 2 ---")
    print(longest_series([1, 1, 1, 2, 2, 3, 3, 3, 3]))

    print("\n--- Задача 3 ---")
    print(top_three_chars("Python Programming"))

    print("\n--- Задача 4 ---")
    print(rotate_matrix_clockwise([[1, 2], [3, 4]]))

    print("\n--- Задача 5 ---")
    print(find_anomalies_pure([10, 12, 11, 100, 9]))

    print("\n--- Задача 6 ---")
    generate_sales_file("sales_data.csv", 100)
    analyze_sales("sales_data.csv")

    print("\n--- Задача 7 ---")
    print(find_most_similar_strings(["abcdef", "abcxef"]))

    print("\n--- Задача 8 ---")
    @retry(2)
    def test_func():
        return "Успешно"
    print(test_func())

    print("\n--- Задача 9 ---")
    s = Store()
    s.add_product(Book("Book", 500, 5, "Author"))
    s.sell_product("Book", 1)

    print("\n--- Задача 10 ---")
    tm = TaskManager()
    tm.add_task(Task("Task 1", "High", "Pending", "2026-10-01"))
    print(tm.get_high_priority_tasks())

if __name__ == "__main__":
    main()
