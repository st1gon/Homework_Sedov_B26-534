from dataclasses import dataclass, asdict
import json
import time
import functools


def measure_execution_time(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        print(f"[Лог времени] Функция '{func.__name__}' выполнилась за {end - start:.6f} сек.")
        return result

    return wrapper


@dataclass
class Task:
    title: str
    priority: str
    status: str
    due_date: str


class TaskManager:
    def __init__(self):
        self.tasks = []

    @measure_execution_time
    def add_task(self, task: Task):
        self.tasks.append(task)

    @measure_execution_time
    def remove_task(self, title: str):
        self.tasks = [t for t in self.tasks if t.title != title]

    @measure_execution_time
    def change_status(self, title: str, new_status: str):
        for t in self.tasks:
            if t.title == title:
                t.status = new_status

    @measure_execution_time
    def get_high_priority_tasks(self):
        return [t for t in self.tasks if t.priority.lower() == "high"]

    @measure_execution_time
    def save_to_json(self, filename="tasks.json"):
        with open(filename, "w", encoding="utf-8") as f:
            json.dump([asdict(t) for t in self.tasks], f, ensure_ascii=False, indent=4)

    @measure_execution_time
    def load_from_json(self, filename="tasks.json"):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.tasks = [Task(**item) for item in data]
        except (FileNotFoundError, json.JSONDecodeError):
            print("Ошибка: Файл поврежден или не найден. Загрузка не удалась.")


if __name__ == "__main__":
    manager = TaskManager()
    manager.add_task(Task("Сделать ДЗ", "High", "Pending", "2026-06-01"))
    manager.add_task(Task("Купить продукты", "Low", "Pending", "2026-06-02"))

    manager.save_to_json()
    manager.load_from_json()
    print("Высокий приоритет:", manager.get_high_priority_tasks())
