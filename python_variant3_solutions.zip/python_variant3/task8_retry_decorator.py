import functools
import random


def retry(num_attempts=3):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(1, num_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    print(
                        f"Попытка {attempt} из {num_attempts} для '{func.__name__}' завершилась ошибкой: {e}"
                    )
            raise last_exception

        return wrapper

    return decorator


@retry(num_attempts=4)
def unstable_function():
    if random.random() < 0.75:
        raise ConnectionError("Сбой соединения!")
    return "Успех!"


if __name__ == "__main__":
    try:
        print(unstable_function())
    except Exception as err:
        print("Итоговая ошибка:", err)
