class Product:
    def __init__(self, name, price, stock):
        self.name = name
        self._price = price
        self.stock = stock

    @property
    def price(self):
        return self._price

    def final_price(self):
        return self._price

    def __str__(self):
        return f"{self.name} | Цена: {self.price} | Остаток: {self.stock}"


class Book(Product):
    def __init__(self, name, price, stock, author):
        super().__init__(name, price, stock)
        self.author = author


class Electronic(Product):
    def __init__(self, name, price, stock, warranty_months):
        super().__init__(name, price, stock)
        self.warranty_months = warranty_months


class Food(Product):
    def __init__(self, name, price, stock, expiry_days):
        super().__init__(name, price, stock)
        self.expiry_days = expiry_days


class Store:
    def __init__(self):
        self.catalog = []

    def add_product(self, product):
        self.catalog.append(product)

    def find_product(self, name):
        for p in self.catalog:
            if p.name.lower() == name.lower():
                return p
        return None

    def sell_product(self, name, quantity):
        product = self.find_product(name)
        if not product:
            print(f"Товар '{name}' не найден.")
            return False
        if product.stock < quantity:
            print(f"Недостаточно товара '{name}' на складе (доступно: {product.stock}).")
            return False
        product.stock -= quantity
        print(f"Успешно продано: {quantity} шт. '{name}'. Остаток: {product.stock}")
        return True


if __name__ == "__main__":
    store = Store()
    store.add_product(Book("Python Basics", 1500, 10, "Guido van Rossum"))
    store.add_product(Electronic("Smartphone", 30000, 3, 12))
    store.add_product(Food("Milk", 90, 20, 7))

    store.sell_product("Smartphone", 1)
    store.sell_product("Smartphone", 5)
